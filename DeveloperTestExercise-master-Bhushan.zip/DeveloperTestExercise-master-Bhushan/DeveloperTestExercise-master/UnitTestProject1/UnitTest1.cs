﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethodVersion()
        {
            ThirdPartyTools.FileDetails objTestversion = new ThirdPartyTools.FileDetails();
            objTestversion.Version("c:/CE.txt");
 
        }
        public void TestMethodSize()
        {
            ThirdPartyTools.FileDetails objTestSize = new ThirdPartyTools.FileDetails();
            objTestSize.Size("c:/CE.txt");
        }
    }
}
